(function() {
    'use strict';
    /*
    * author:广州银云信息科技有限公司
    * 常量模块
    */
    angular.module('goku.constant', [])
})();