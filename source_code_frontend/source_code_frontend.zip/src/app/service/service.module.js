(function() {
    'use strict';
    /*
     * author：广州银云信息科技有限公司
     * 服务模块定义js
     */
    angular.module('goku.service', [])
})();
