(function () {
    'use strict';
    /*
     * author：广州银云信息科技有限公司
     * 专业版本专用弹窗controller js
     */
    angular.module('goku.modal')

        .directive('eoGatewayModal', [function () {
            return {
                restrict: 'AE',
                templateUrl: 'app/modal/branch/gateway/index.html'
            }
        }])

        .controller('Gateway_DefaultModalCtrl', Gateway_DefaultModalCtrl)

        .controller('GatewayBackendModalCtrl', GatewayBackendModalCtrl)

        .controller('GatewayRateLimitModalCtrl', GatewayRateLimitModalCtrl)

        .controller('Gateway_ChangePasswordModalCtrl', Gateway_ChangePasswordModalCtrl)

    Gateway_ChangePasswordModalCtrl.$inject = ['$scope', '$uibModalInstance', '$rootScope', 'CommonResource', 'CODE', 'input'];

    function Gateway_ChangePasswordModalCtrl($scope, $uibModalInstance, $rootScope, CommonResource, CODE, input) {
        $scope.data = {
            input: {},
            interaction: {
                request: {
                    oldPassword: '',
                    newPassword: ''
                }
            },
            fun: {
                confirm: null, //确认修改功能函数
            }
        }
        $scope.data.fun.confirm = function () {
            var template = {
                request: {
                    oldPassword: CryptoJS.MD5($scope.data.interaction.request.oldPassword).toString(),
                    newPassword: CryptoJS.MD5($scope.data.interaction.request.newPassword).toString()
                }
            }
            if ($scope.editForm.$valid) {
                CommonResource.User.Password(template.request).$promise
                    .then(function (response) {
                        switch (response.statusCode) {
                            case CODE.COMMON.SUCCESS:
                            case CODE.USER.UNCHANGE:
                                {
                                    $rootScope.InfoModal('修改成功', 'success');
                                    $uibModalInstance.close(true);
                                    break;
                                }
                            case CODE.USER.ERROR:
                                {
                                    $rootScope.InfoModal('旧密码错误', 'error');
                                    break;
                                }
                        }
                    })
            }
        }
        $scope.cancel = function () {
            $uibModalInstance.close(false);
        };
    }

    Gateway_DefaultModalCtrl.$inject = ['$scope', '$uibModalInstance', '$filter', 'GatewayResource', 'CODE', 'input'];

    function Gateway_DefaultModalCtrl($scope, $uibModalInstance, $filter, GatewayResource, CODE, input) {
        $scope.interaction = {
            request: {
                gatewayName: '',
                gatewayDesc: ''
            }
        }
        $scope.data = {
            title: input.title,
            status: input.status
        }
        $scope.fun = {};
        var fun = {
            init: null
        }
        var data = {
            aliasAjax: null
        }

        /**
         * 初始化信息
         */
        fun.init = (function () {
            switch (input.status) {
                case 'edit':
                    {
                        $scope.interaction.request = angular.copy(input.request);
                        break;
                    }
            }
            $scope.$watch('interaction.request.gatewayAlias', function () {
                fun.checkAlias();
            }, true);
        })()

        $scope.fun.random = function () {
            $scope.interaction.request.gatewayAlias = $filter('tokenFilter')($scope.interaction.request.gatewayName);
        }
        fun.checkAlias = function () {
            if (!$scope.interaction.request.gatewayAlias) return;
            var template = {
                request: {
                    gatewayAlias: $scope.interaction.request.gatewayAlias
                }
            }
            if (data.aliasAjax) {
                data.aliasAjax.$cancelRequest();
            }
            data.aliasAjax = GatewayResource.Gateway.CheckAlias(template.request);
            data.aliasAjax.$promise.then(function (response) {
                switch (response.statusCode) {
                    case CODE.COMMON.SUCCESS:
                        {
                            $scope.ConfirmForm.alias.$invalid = true;
                            break;
                        }
                }
            })
        }
        /**
         * 确认保存网关
         */
        $scope.fun.confirm = function () {
            if ($scope.ConfirmForm.$valid) {
                switch (input.status) {
                    case 'add':
                        {
                            GatewayResource.Gateway.Add($scope.interaction.request).$promise.then(function (response) {
                                switch (response.statusCode) {
                                    case CODE.COMMON.SUCCESS:
                                        {
                                            $scope.interaction.request.gatewayHashKey = response.gatewayHashKey;
                                            $uibModalInstance.close($scope.interaction.request);
                                            break;
                                        }
                                    default:
                                        {
                                            $scope.submited = true;
                                            break;
                                        }
                                }
                            });
                            break;
                        }
                    default:
                        {
                            GatewayResource.Gateway.Edit($scope.interaction.request).$promise.then(function (response) {
                                switch (response.statusCode) {
                                    case CODE.COMMON.SUCCESS:
                                        {
                                            $uibModalInstance.close($scope.interaction.request);
                                            break;
                                        }
                                    default:
                                        {
                                            $scope.submited = true;
                                            break;
                                        }
                                }
                            });
                            break;
                        }
                }
            } else {
                $scope.submited = true;
            }
        };

        /**
         * 取消编辑
         */
        $scope.fun.cancel = function () {
            $uibModalInstance.close(false);
        };
    }

    GatewayBackendModalCtrl.$inject = ['$scope', '$uibModalInstance', '$timeout', 'CODE', 'title', 'info'];

    function GatewayBackendModalCtrl($scope, $uibModalInstance, $timeout, CODE, title, info) {
        var code = CODE.COMMON.SUCCESS;
        var vm = this;
        $scope.title = title;
        $scope.info = {
            backendName: '',
            backendURI: '',
            isAdd: true
        }

        function init() {
            if (info) {
                $scope.info = {
                    backendID: info.backendID,
                    backendName: info.backendName,
                    backendURI: info.backendURI,
                    isAdd: false
                }
            }
        }
        init();
        $scope.ok = function () {
            if ($scope.ConfirmForm.$valid) {
                $uibModalInstance.close($scope.info);
            } else {
                $scope.submited = true;
            }
        };

        $scope.cancel = function () {
            //$uibModalInstance.dismiss(false);
            $uibModalInstance.close(false);
        };
    }

    GatewayRateLimitModalCtrl.$inject = ['$scope', '$uibModalInstance', 'input'];

    function GatewayRateLimitModalCtrl($scope, $uibModalInstance, input) {
        var vm = this;
        $scope.data = {
            constant: {
                viewArray: [{
                    name: '允许访问',
                    id: 0
                }, {
                    name: '禁止访问',
                    id: 1
                }],
                intervalArray: [{
                    name: '1秒',
                    id: 0
                }, {
                    name: '1分钟',
                    id: 1
                }, {
                    name: '1小时',
                    id: 2
                }, {
                    name: '1天',
                    id: 3
                }],
                timeArray: [{
                    id: '00:00'
                }, {
                    id: '01:00'
                }, {
                    id: '02:00'
                }, {
                    id: '03:00'
                }, {
                    id: '04:00'
                }, {
                    id: '05:00'
                }, {
                    id: '06:00'
                }, {
                    id: '07:00'
                }, {
                    id: '08:00'
                }, {
                    id: '09:00'
                }, {
                    id: '10:00'
                }, {
                    id: '11:00'
                }, {
                    id: '12:00'
                }, {
                    id: '13:00'
                }, {
                    id: '14:00'
                }, {
                    id: '15:00'
                }, {
                    id: '16:00'
                }, {
                    id: '17:00'
                }, {
                    id: '18:00'
                }, {
                    id: '19:00'
                }, {
                    id: '20:00'
                }, {
                    id: '21:00'
                }, {
                    id: '22:00'
                }, {
                    id: '23:00'
                }, {
                    id: '23:59'
                }]
            }
        };
        $scope.input = angular.copy(input);
        $scope.fun = {};
        $scope.fun.confirm = function () {
            if ($scope.ConfirmForm.$valid) {
                switch ($scope.input.request.viewType) {
                    case 1:
                        {
                            try {
                                delete $scope.input.request['intervalType'];
                                delete $scope.input.request['limitCount'];
                            } catch (e) {
                                console.error(e)
                            }
                            break;
                        }
                }
                $uibModalInstance.close($scope.input.request);
            }
        };

        $scope.fun.cancel = function () {
            //$uibModalInstance.dismiss(false);
            $uibModalInstance.close(false);
        };
    }


})();