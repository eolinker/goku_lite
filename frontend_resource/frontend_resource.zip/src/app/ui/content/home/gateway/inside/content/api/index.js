(function() {
    'use strict';
    /*
     * author：riverLethe
     * 网关内页页内包模块api相关js
     */
    angular.module('goku')
        .config(['$stateProvider', 'RouteHelpersProvider', function($stateProvider, helper) {
            $stateProvider
                .state('home.gateway.inside.api', {
                    url: '/api',
                    template: '<gateway-api-sidebar></gateway-api-sidebar><gpedit-gateway-component ></gpedit-gateway-component><div ui-view></div>'
                });
        }])
})();
