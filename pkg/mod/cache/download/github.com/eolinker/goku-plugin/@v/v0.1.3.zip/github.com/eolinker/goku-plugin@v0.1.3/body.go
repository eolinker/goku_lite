package goku_plugin

const (
	MultipartForm  = "multipart/form-data"
	FormData       = "application/x-www-form-urlencoded"
	TEXT           = "text/plain"
	JSON           = "application/json"
	JavaScript     = "application/javascript"
	AppLicationXML = "application/xml"
	TextXML        = "text/xml"
	Html           = "text/html"
)

//func (t RequestType)String()string  {
//	switch t {
//	case RequestRaw :{
//		return "RequestRaw"
//	}
//	case RequestForm:{
//			return "RequestForm"
//		}
//
//	case	RequestMultipart:{
//			return "RequestMultipart"
//		}
//	case	RequestJson:{
//			return "RequestJson"
//		}
//	case	RequestXML:{
//			return "RequestXML"
//		}
//	}
//	return "unknown"
//}
