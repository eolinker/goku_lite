# goku-plugin
goku网关自定义插件实现接口
