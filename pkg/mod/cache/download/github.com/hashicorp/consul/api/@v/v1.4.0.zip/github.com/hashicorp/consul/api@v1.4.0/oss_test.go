// +build !consulent

package api

var defaultNamespace = ""
