// +build !debug

package sftp

func debug(fmt string, args ...interface{}) {}
